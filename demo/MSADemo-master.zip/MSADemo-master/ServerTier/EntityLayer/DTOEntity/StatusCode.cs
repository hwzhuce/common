﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTOEntity
{
    public enum StatusCode
    {
        NotSet = -1,
        InActive = 0,
        Active = 1
    }
}
