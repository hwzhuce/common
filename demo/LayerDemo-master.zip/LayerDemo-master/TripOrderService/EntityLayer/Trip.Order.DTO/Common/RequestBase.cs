﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trip.Order.DTO
{
    /// <summary>
    /// 请求参数DTO实体类的基类
    /// </summary>
    public class RequestBase
    {
    }
}
