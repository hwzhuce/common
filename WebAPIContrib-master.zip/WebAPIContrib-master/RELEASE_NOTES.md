### New in 2.0.0 (Released 2016-02-17)
* Version 2.0

### New in 1.0.0 (Released 2015-02-28)
* Version 1.0
* New build

### New in 0.9.14 (Released 2013-11-14)
* Previous release
