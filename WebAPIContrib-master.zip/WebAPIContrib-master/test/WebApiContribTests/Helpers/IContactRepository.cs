namespace WebApiContribTests.Helpers
{
    public interface IContactRepository
    {
    }
}