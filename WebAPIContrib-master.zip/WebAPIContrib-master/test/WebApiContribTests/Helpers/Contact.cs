using System;

namespace WebApiContribTests.Helpers
{
    public class Contact
    {
        public DateTime Birthday { get; set; }

        public int Id { get; set; }
    }
}