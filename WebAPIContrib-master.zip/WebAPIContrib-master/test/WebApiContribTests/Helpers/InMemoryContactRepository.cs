namespace WebApiContribTests.Helpers
{
    public class FileContactRepository : IContactRepository
    {
    }

    public class InMemoryContactRepository : IContactRepository
    {
    }
}