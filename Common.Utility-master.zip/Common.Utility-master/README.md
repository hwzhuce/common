
## 比较全面的c#帮助类

日常工作总结，加上网上收集，各式各样的几乎都能找到,所有功能性代码都是独立的类，类与类之间没有联系，可以单独引用至项目，分享出来，方便大家，几乎都有注释，喜欢的请点赞，不断完善收集中... 
## 样板图片操作类
![WEFE@M%}SN4_K$6H0D{6IYJ.png](http://upload-images.jianshu.io/upload_images/6855212-34f0ee0339e3cb49.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
## 操作文档
里面包含一下操作文档，这个是用Sandcastle工具生成的。方法：四种Sandcastle方法生成c#.net帮助类帮助文档，地址：http://www.cnblogs.com/anyushengcms/p/7682501.html
![H819EQUYFVA~WXK6YAQ1%6Q.png](http://upload-images.jianshu.io/upload_images/6855212-6cf5a7a2a4a75c89.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
## 附上一些常见的帮助类栏目
1. cookie操作 --------- CookieHelper.cs
2. session操作 ------- SessionHelper.cs
3. cache操作
4. ftp操作
5. http操作 ------------ HttpHelper.cs
6. json操作 ------------ JsonHelper.cs		
7. xml操作 ------------- XmlHelper.cs
8. Excel操作			
9. Sql操作 ------------- SqlHelper.cs
10. 类型转换 ------------ Converter.cs
11. 加密解密 ------------ EncryptHelper.cs	
12. 邮件发送	------------ MailHelper.cs
13. 二维码
14. 汉字转拼音
15. 计划任务	------------ IntervalTask.cs
16. 信息配置 ------------ Setting.cs
17. 上传下载配置文件操作类
18. 视频转换
19. 图片操作
20. 验证码生成
21. String拓展 ---------- StringExtension.cs
22. 正则表达式 --------- RegexHelper.cs
23. 分页操作
24. UBB编码
25. Url重写
26. Object拓展 --------- ObjectExtension.cs
27. Stream的拓展	------ StreamExtension.cs
28. CSV文件转换
29. Chart图形
30. H5-微信
31. PDF
32. 分词辅助类
33. 序列化
34. 异步线程
35. 弹出消息类
36. 文件操作类
37. 日历
38. 日志
39. 时间操作类
40. 时间戳
41. 条形码
42. 正则表达式
43. 汉字转拼音
44. 网站安全
45. 网络
46. 视频转换类
47. 计划任务
48. 配置文件操作类
49. 阿里云
50. 随机数类
51. 页面辅助类
52. 验证码
53. Mime
54. Net
55. NPOI
56. obj
57. Path
58. Properties
59. ResourceManager
60. URL的操作类
61. VerifyCode
62. 处理多媒体的公共类
63. 各种验证帮助类
64. 分页
65. 计划任务
66. 配置文件操作类
67. 分词辅助类
68. IP辅助类
69. Html操作类
70. 其他
