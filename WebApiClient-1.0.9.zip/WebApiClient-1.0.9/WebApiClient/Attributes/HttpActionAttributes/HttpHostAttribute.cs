﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApiClient.Attributes
{
    /// <summary>
    /// 表示请求服务http绝对完整主机域名
    /// 例如http://www.webapiclient.com
    /// 不可继承
    /// </summary>
    [DebuggerDisplay("Host = {Host}")]
    public sealed class HttpHostAttribute : ApiActionAttribute
    {
        /// <summary>
        /// 获取根路径
        /// </summary>
        public Uri Host { get; private set; }

        /// <summary>
        /// 获取顺序排序索引
        /// 优先级最高
        /// </summary>
        public override int OrderIndex
        {
            get
            {
                return int.MinValue;
            }
        }

        /// <summary>
        /// 请求服务的根路径
        /// 例如http://www.webapiclient.com
        /// </summary>
        /// <param name="host">请求完整绝对根路径</param>
        /// <exception cref="ArgumentNullException"></exception>
        /// <exception cref="UriFormatException"></exception>
        public HttpHostAttribute(string host)
        {
            this.Host = new Uri(host, UriKind.Absolute);
        }

        /// <summary>
        /// 执行前
        /// </summary>
        /// <param name="context">上下文</param>
        /// <returns></returns>
        public override Task BeforeRequestAsync(ApiActionContext context)
        {
            if (context.HttpApiConfig.HttpHost == null)
            {
                context.RequestMessage.RequestUri = this.Host;
            }
            return ApiTask.CompletedTask;
        }

        /// <summary>
        /// 转换为字符串
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.Host.ToString();
        }
    }
}
