﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApi.Controllers
{
    public class RestaurantController : ApiController
    {
		List<Restaurant> restaurants = new List<Restaurant>() { 
				new Restaurant(){ Id = 1, Name = "Restaurant Test 1", Address = "1111 Oxford Street" },
				new Restaurant(){ Id = 2, Name = "Restaurant Test 2", Address = "2222 Oxford Street" },
				new Restaurant(){ Id = 3, Name = "Restaurant Test 3", Address = "3333 Oxford Street" },
				new Restaurant(){ Id = 4, Name = "Restaurant Test 4", Address = "4444 Oxford Street" }
			};

        // GET: api/Restaurant
        public IEnumerable<Restaurant> Get()
        {
			return restaurants;
        }

        // GET: api/Restaurant/5
		public Restaurant Get(int id)
        {
            return restaurants.SingleOrDefault(r => r.Id == id);
        }

        // POST: api/Restaurant
		public void Post([FromBody]Restaurant value)
        {
			restaurants.Add(value);
        }

        // PUT: api/Restaurant/5
		public void Put([FromBody]Restaurant value)
        {
			restaurants.RemoveAll(r => r.Id == value.Id);
			restaurants.Add(value);
        }

        // DELETE: api/Restaurant/5
        public void Delete(int id)
        {
			restaurants.RemoveAll(r => r.Id == id);
		}
    }
}
