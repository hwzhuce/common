﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DTO;
using WebApiRestService;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Mvc.Controllers
{
    public class RestaurantsController : Controller
    {
		private WebApiClientOptions options = new WebApiClientOptions("http://localhost:60214/api", "restaurant");

        public async Task<ActionResult> Index()
        {
			List<Restaurant> list = null;

			using(WebApiClient<Restaurant> client = new WebApiClient<Restaurant>(options))
			{
				list = await client.GetManyAsync();
			}

            return View(list);
        }

		public async Task<ActionResult> IndexOldFashioned()
		{
			List<Restaurant> list = null;

			HttpClient client = new HttpClient();
			client.BaseAddress = new Uri("http://localhost:60214/api/");
			client.DefaultRequestHeaders.Accept.Clear();
			client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			var response = await client.GetAsync("restaurant");

			if (!response.IsSuccessStatusCode)
			{
				return new HttpStatusCodeResult(HttpStatusCode.InternalServerError); 
			}

			list = await response.Content.ReadAsAsync<List<Restaurant>>();
			
			return View("Index", list);
		}

        public async Task<ActionResult> Details(int? id)
        {
			Restaurant restaurant = null;

			if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

			using (WebApiClient<Restaurant> client = new WebApiClient<Restaurant>(options))
			{
				restaurant = await client.GetOneAsync(id);
			}
			
            if (restaurant == null)
            {
                return HttpNotFound();
            }
            
			return View(restaurant);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Restaurant restaurant)
        {
            if (ModelState.IsValid)
            {
				using (WebApiClient<Restaurant> client = new WebApiClient<Restaurant>(options))
				{
					await client.CreateAsync(restaurant);
				}
				
				return RedirectToAction("Index");
            }

            return View(restaurant);
        }

        public async Task<ActionResult> Edit(int? id)
        {
			Restaurant restaurant = null;

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
			
			using (WebApiClient<Restaurant> client = new WebApiClient<Restaurant>(options))
			{
				restaurant = await client.GetOneAsync(id);
			}
			
			if (restaurant == null)
            {
                return HttpNotFound();
            }
            
			return View(restaurant);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Restaurant restaurant)
        {
            if (ModelState.IsValid)
            {
				using (WebApiClient<Restaurant> client = new WebApiClient<Restaurant>(options))
				{
					await client.EditAsync(restaurant);
				}
				
				return RedirectToAction("Index");
            }
            
			return View(restaurant);
        }

        public async Task<ActionResult> Delete(int? id)
        {
			Restaurant restaurant = null;

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
			
			using (WebApiClient<Restaurant> client = new WebApiClient<Restaurant>(options))
			{
				restaurant = await client.GetOneAsync(id);
				
				if (restaurant == null)
				{
					return HttpNotFound();
				}
			}
            
			return View(restaurant);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(Restaurant restaurant)
        {
			if (restaurant == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}

			using (WebApiClient<Restaurant> client = new WebApiClient<Restaurant>(options))
			{
				restaurant = await client.GetOneAsync(restaurant.Id);

				if (restaurant == null)
				{
					return HttpNotFound();
				}

				await client.DeleteAsync(restaurant.Id);
			}

			return RedirectToAction("Index");
        }
    }
}
